﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2910_201_MitchellJabari_Lab5
{
	internal class Pokemon
	{
		public string name { get; set; }
		public string url { get; set; }
	}
}
