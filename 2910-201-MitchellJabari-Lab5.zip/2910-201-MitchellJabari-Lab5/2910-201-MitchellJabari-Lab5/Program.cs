﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Http;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace _2910_201_MitchellJabari_Lab5
{
	internal class Program
	{
		static void Main(string[] args)
		{
			bool isRunning = true;
			string fetch = $"https://pokeapi.co/api/v2/pokemon-form/";

			while (isRunning)
			{
				try
				{
					Menu();
					int choice = Int32.Parse(Console.ReadLine());
					if (choice == 4)
					{
						Console.WriteLine("Thank you for using the pokedex.");
						isRunning = false;
					}
					else
					{
						MenuChoice(choice, fetch);
					}
				}
				catch (FormatException ex)
				{
					Console.WriteLine("Please only input a number that corresponds to a menu choice.");
				}
			}
		}

		static void Menu()
		{
			Console.WriteLine("----------------------------------------------------------");
			Console.WriteLine("\t\tPokedex Menu");
			Console.WriteLine("----------------------------------------------------------");
			Console.WriteLine("1. Random Pokemon");
			Console.WriteLine("2. Pick a Pokemon");
			Console.WriteLine("3. List 5 random Pokemon");
			Console.WriteLine("4. Exit");
			Console.WriteLine("----------------------------------------------------------");
			Console.WriteLine("Enter an Option:");
		}

		static async void MenuChoice(int choice, string fetch)
		{
			switch (choice)
			{
				case 1: //Random Pokemon
					Random ran = new Random();
					int randomID = ran.Next(0, 1026);
					fetch += $"{randomID}/";
					using (HttpClient client = new HttpClient())
					{
						HttpResponseMessage response = await client.GetAsync(fetch);

						if (response.IsSuccessStatusCode)
						{
							string responseBody = await response.Content.ReadAsStringAsync();

							Pokemon pokemon = JsonConvert.DeserializeObject<Pokemon>(responseBody);
							Console.WriteLine(pokemon.name);
						}
					}
					break;

				case 2: //Pick a Pokemon
					bool goodInput = false;
					string json;
					string pkmnName;

					try
					{
						Console.WriteLine("What is the Pokedex number of the pokemon you'd like to view?");
						int pkmnID = Int32.Parse(Console.ReadLine());
						do
						{
							if (0 < pkmnID && pkmnID < 1026)
							{
								fetch += $"{pkmnID}/";

								using (HttpClient client = new HttpClient())
								{
									HttpResponseMessage response = await client.GetAsync(fetch);

									if (response.IsSuccessStatusCode)
									{
										string responseBody = await response.Content.ReadAsStringAsync();

										Pokemon pokemon = JsonConvert.DeserializeObject<Pokemon>(responseBody);
										Console.WriteLine(pokemon.name);
									}
								}
								goodInput = true;
							}
							else
							{
								Console.WriteLine("Please say a dex number of an exisiting Pokemon (1-1025)");
								goodInput = false;
							}
						}
						while (goodInput);
					}
					catch (FormatException ex)
					{
						Console.WriteLine("Please only enter the pokedex number corresponding to the pokemon you want.");
					}
					break;
				case 3:
					Random random = new Random();
					List<Pokemon> randomPokemon = new List<Pokemon>();
					
					for (int i = 0; i < 6; i++)
					{
						int randomI = random.Next(0, 1026);
						fetch += $"{randomI}/";
						using (HttpClient client = new HttpClient())
						{
							HttpResponseMessage response = await client.GetAsync(fetch);

							if (response.IsSuccessStatusCode)
							{
								string responseBody = await response.Content.ReadAsStringAsync();

								Pokemon pokemon = JsonConvert.DeserializeObject<Pokemon>(responseBody);
								randomPokemon.Add(pokemon);
							}
						}
					}

					foreach(Pokemon pokemon in randomPokemon)
					{
						Console.WriteLine(pokemon.name);
					}
					break;

				default:
					Console.WriteLine("Please only input a number that corresponds to a menu choice.");
					break;
			}
		}
	}
}